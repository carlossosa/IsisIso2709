perl ./prepare_xml.pl marc.ldb.iso.xml marc.ldb.iso.list_vruchnu.xml
