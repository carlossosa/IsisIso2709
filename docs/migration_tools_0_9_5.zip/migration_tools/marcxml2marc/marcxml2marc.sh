perl ./marcxml2marc.pl Kniga.iso_utf8.xml
