perl ./iso2xml.pl  Kniga.iso>Kniga.iso\(LOG\).txt
